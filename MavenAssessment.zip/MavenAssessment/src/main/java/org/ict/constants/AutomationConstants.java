package org.ict.constants;

public class AutomationConstants {

	public static String expusername="practice.swtesting@gmail.com";
	public static String expPassword="123";
	public static  String ExpectedValue=":: ICT ACADEMY OF KERALA ::";
	

	
	
    public static String expname="Sruthi K S";
	public static String exppassword="sruthi@123";
	public static String expemail="sruthiks@gmail.com";
	public static String expdesignation="ARM";
	public static String expreportingto="Demo";
	public static String expmemberof="Staff";
    public static String expempid="123456";
	public static String exppassword2="sruthi@123";
	public static String expnumber="8281481676";
	public static String exptype="Permanent";
	public static String expaddress="Kollam";
}
